function [ y ] = FSK_sample_judge( x1,x2,delta_T )

length_ori=length(x1)/delta_T;
for i=1:length_ori
    if x1((i-1)*delta_T+delta_T/2) > x2((i-1)*delta_T+delta_T/2)
        y(i)=1;
    else y(i)=0;
    end
end
end


